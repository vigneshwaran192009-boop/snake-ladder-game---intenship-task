SNAKE & LADDER GAME

Language: Python 3
Library: Tkinter (usually included with Python)

HOW TO RUN:
1. Open this folder in VS Code.
2. Open Terminal.
3. Run: python main.py

FEATURES:
- 1 to 100 board
- Random dice from 1 to 6
- Two players
- Snake penalties and ladder advances
- Winner announcement at square 100
- New Game button

WEB VERSION:
- Open index.html in any browser (no installation needed).
