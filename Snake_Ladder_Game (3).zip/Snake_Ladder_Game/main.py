import tkinter as tk
import random
from tkinter import messagebox

SNAKES = {99: 54, 70: 55, 52: 42, 25: 2, 95: 72}
LADDERS = {6: 25, 11: 40, 46: 90, 60: 85, 17: 69}

class Game:
    def __init__(self, root):
        self.root = root
        root.title("Snake and Ladder Game")
        root.geometry("650x730")
        root.configure(bg="#17202a")
        self.pos = [0, 0]
        self.turn = 0
        tk.Label(root, text="SNAKE & LADDER", font=("Arial", 24, "bold"),
                 bg="#17202a", fg="white").pack(pady=10)
        self.status = tk.Label(root, text="Player 1's turn", font=("Arial", 15, "bold"),
                               bg="#17202a", fg="#00c8e8")
        self.status.pack()
        self.board = tk.Canvas(root, width=600, height=600, bg="white")
        self.board.pack(pady=10)
        controls = tk.Frame(root, bg="#17202a")
        controls.pack()
        tk.Button(controls, text="ROLL DICE", command=self.roll,
                  bg="#00c8e8", font=("Arial", 12, "bold"), padx=15).pack(side="left", padx=8)
        tk.Button(controls, text="NEW GAME", command=self.reset,
                  font=("Arial", 12, "bold"), padx=15).pack(side="left", padx=8)
        self.draw()

    def center(self, n):
        r = (n - 1) // 10
        c = (n - 1) % 10
        if r % 2: c = 9 - c
        return c * 60 + 30, (9-r) * 60 + 30

    def draw(self):
        self.board.delete("all")
        for n in range(1, 101):
            x, y = self.center(n)
            color = "#d6eaf8" if (n + (n-1)//10) % 2 else "#eaf2f8"
            self.board.create_rectangle(x-29, y-29, x+29, y+29,
                                        fill=color, outline="#85929e")
            self.board.create_text(x, y-12, text=str(n), fill="#34495e",
                                   font=("Arial", 8))
        for a, b in SNAKES.items():
            x1,y1 = self.center(a); x2,y2 = self.center(b)
            self.board.create_line(x1,y1,x2,y2,fill="#e74c3c",width=5,arrow=tk.LAST)
            self.board.create_text((x1+x2)//2,(y1+y2)//2,text="S",
                                   fill="#922b21",font=("Arial",12,"bold"))
        for a, b in LADDERS.items():
            x1,y1 = self.center(a); x2,y2 = self.center(b)
            self.board.create_line(x1-4,y1,x2-4,y2,fill="#27ae60",width=4)
            self.board.create_line(x1+4,y1,x2+4,y2,fill="#27ae60",width=4)
        for i, p in enumerate(self.pos):
            if p:
                x,y = self.center(p); dx = -10 if i == 0 else 10
                self.board.create_oval(x+dx-9,y+4,x+dx+9,y+22,
                                       fill=("#00c8e8","#ffb347")[i],outline="black")
                self.board.create_text(x+dx,y+13,text=str(i+1),font=("Arial",8,"bold"))

    def roll(self):
        d = random.randint(1,6)
        p = self.turn
        target = self.pos[p] + d
        msg = f"Player {p+1} rolled {d}. "
        if target <= 100:
            self.pos[p] = target
            if target in SNAKES:
                self.pos[p] = SNAKES[target]
                msg += f"Snake! Go down to {self.pos[p]}."
            elif target in LADDERS:
                self.pos[p] = LADDERS[target]
                msg += f"Ladder! Climb to {self.pos[p]}."
        else:
            msg += "You need an exact roll to reach 100."
        self.draw()
        if self.pos[p] == 100:
            self.status.config(text=f"Player {p+1} wins!")
            messagebox.showinfo("Winner", f"Player {p+1} wins!")
            return
        messagebox.showinfo("Dice Result", msg)
        self.turn = 1 - self.turn
        self.status.config(text=f"Player {self.turn+1}'s turn")

    def reset(self):
        self.pos = [0,0]
        self.turn = 0
        self.status.config(text="Player 1's turn")
        self.draw()

if __name__ == "__main__":
    root = tk.Tk()
    Game(root)
    root.mainloop()
